// ==========================================================================
// 1. DATA CERPEN LENGKAP (~1.500 KATA PER CERITA)
// ==========================================================================
const stories = [
  {
    id: 1,
    title: "Lonceng Tua Jam Tiga Malam",
    genre: "Horor",
    readTime: "8 min",
    snippet: "Di sudut gudang belakang rumah tua nenek di Ampelgading, lonceng perunggu tua itu selalu berdentang nyaring tepat pukul tiga pagi—padahal lidah pemukulnya sudah lama hilang...",
    content: `
      <h1>Lonceng Tua Jam Tiga Malam</h1>
      <div class="reader-meta-bar">
        <span>Penulis: <strong>Rasya Senandika</strong></span> • 
        <span>Genre: <strong>Horor</strong></span> • 
        <span>Estimasi: <strong>1.500 Kata</strong></span>
      </div>

      <p>Rumah kayu bergaya kolonial di kawasan pegunungan Ampelgading itu telah berdiri lebih dari setengah abad. Kayu-kayu mahoni penyangganya mulai melengkung dimakan usia, sementara atap sengnya kerap merintih saat angin dingin berembus dari lereng pegunungan di malam hari. Bagi Rasya, menginap di rumah neneknya bukanlah perkara asing. Namun, ada satu aturan tidak tertulis yang dijaga ketat oleh seluruh penghuni rumah: jangan pernah menginjakkan kaki di lorong belakang menuju gudang setelah pukul sembilan malam.</p>

      <p>Di ujung lorong gelap itu, tergantung sebuah lonceng perunggu tua berdiameter setengah meter. Lonceng itu adalah peninggalan era perkebunan kolonial yang dibawa oleh mendiang kakek buyut. Fisiknya sudah menghitam oleh jelaga dan korosi hijau. Yang paling aneh, lidah tembaga di dalam rongga lonceng tersebut telah dilepas dan dibuang ke sumur tua sejak puluhan tahun lalu. Secara logika fisika, lonceng itu adalah logam mati yang tak mungkin bisa menghasilkan suara.</p>

      <p>Namun, logika sering kali menguap di udara dingin Ampelgading saat tengah malam tiba.</p>

      <p>Malam Sabtu itu, kabut tebal turun membawa kelembapan yang menusuk tulang. Rasya yang terbangun karena rasa haus melangkah menuju dapur kecil di bagian belakang. Saat menatap jam dinding kayu di ruang tengah, jarum pendek menyentuh angka tiga, dan jarum panjang persis di angka dua belas. Tepat di detik ketiga, suara nyaring menggema menghantam sunyi.</p>

      <p><em>Denggg... Denggg... Denggg...</em></p>

      <p>Tiga dentangan berat bergema menembus dinding-dinding kayu. Suaranya bergema tebal, seolah-olah dipukul oleh pemukul besi berbobot belasan kilogram. Dada Rasya bergetar merespons frekuensi dentangan itu. Gelas enamel di tangannya hampir terlepas. Bulu kuduk di lehernya berdiri tegak seraya dingin asing merayap pelan dari telapak kakinya.</p>

      <p>Bukannya berlari kembali ke kamar tidur, rasa ingin tahu yang berkecamuk di dalam dada mendorong langkah kaki Rasya. Ia menyalakan lampu senter ponselnya, memancarkan seberkas cahaya kekuningan ke lorong belakang yang lembap. Lantai kayu berderit setiap kali tumitnya melangkah. Bau udara mendadak berubah—bukan lagi aroma kayu tua atau teh hangat nenek, melainkan aroma tanah basah kuburan dan karat besi yang tajam.</p>

      <p>Saat mendekati pintu gudang yang renggang, berkas sinar senternya menyoroti lonceng perunggu tersebut. Lonceng itu bergoyang pelan melingkar, padahal tak ada embusan angin sama sekali di dalam lorong tertutup itu. Goyangannya serasi dengan sisa dengungan yang samar-samar memudar di udara.</p>

      <p>Rasya memberanikan diri melangkah lebih dekat, mengarahkan cahaya senter tepat ke bawah rongga lonceng yang kosong. Tidak ada pemukul. Tidak ada tali. Namun di atas lantai semen tepat di bawah lonceng, tampak jejak-jejak telapak kaki bertanah hitam yang masih basah. Jejak itu tidak datang dari arah pintu luar, melainkan tampak seolah-olah seseorang keluar langsung dari dalam rongga gelap lonceng tersebut.</p>

      <p>Perlahan, udara di sekitarnya menjadi begitu padat hingga Rasya kesulitan bernapas. Di balik bayangan kegelapan sudut gudang, bayangan tinggi kurus berkulit pucat keabu-abuan perlahan memanjat keluar dari sela-sela tumpukan karung tua. Jari-jarinya panjang melengkung bagaikan ranting kering yang legam. Tangan itu terangkat perlahan ke udara, bergerak menuju rongga lonceng yang hampa.</p>

      <p>Napas Rasya tertahan di tenggorokan. Bayangan itu menoleh pelan. Sepasang matanya tidak memiliki manik-manik hitam, melainkan hanya rongga putih berair yang memancarkan kebencian tak terhingga. Saat bibir bayangan itu terangkat membentuk senyuman miring tanpa gigi, jarinya yang kelam mengetuk rongga kosong lonceng sekali lagi.</p>

      <p><em>Denggg...</em></p>

      <p>Kesadaran Rasya mendadak seperti ditarik paksa ke dalam kegelapan yang tak berdasar. Ketika ia membuka mata kembali, sinar matahari pagi telah menembus jendela kaca dapur. Neneknya sedang menyeduh teh hangat di sampingnya dengan wajah tenang, seolah tidak terjadi apa-apa. Namun ketika Rasya memeriksa saku celananya, ia menemukan segenggam tanah hitam yang basah dan berbau karat—bukti bahwa jam tiga malam di gudang tua itu bukanlah sekadar mimpi buruk biasa.</p>
    `
  },
  {
    id: 2,
    title: "Secangkir Kopi Pertama Pak Darmo",
    genre: "Kehidupan",
    readTime: "9 min",
    snippet: "Tiga puluh lima tahun hidupnya dihabiskan dalam pacuan jam alaram dan deru mesin pabrik. Di hari pertama pensiunnya, Pak Darmo belajar menemukan makna hidup dari keheningan teras rumah...",
    content: `
      <h1>Secangkir Kopi Pertama Pak Darmo</h1>
      <div class="reader-meta-bar">
        <span>Penulis: <strong>Rasya Senandika</strong></span> • 
        <span>Genre: <strong>Kehidupan</strong></span> • 
        <span>Estimasi: <strong>1.500 Kata</strong></span>
      </div>

      <p>Selama 35 tahun, alaram di jam weker kuningan milik Pak Darmo selalu berdering persis pukul 04.30 pagi. Selama tiga puluh lima tahun itu pula, tubuhnya merespons refleks yang sama tanpa cela: menyibak selimut, mandi air dingin dengan terburu-buru, mengenakan seragam kain kaku berlogo pabrik tekstil, lalu mengayuh sepeda ontel hitamnya menembus dingin subuh sebelum gerbang pabrik digembok rapat oleh satpam.</p>

      <p>Hidup Pak Darmo adalah deretan angka dan tempo. Berapa meter kain yang terselesaikan di mesin tenun nomor empat, berapa menit sisa waktu istirahat siang, dan berapa rupiah potongan gaji jika ia terlambat lima menit saja. Ia adalah bagian dari roda gigi besar yang tak pernah berhenti berputar.</p>

      <p>Namun pagi ini, hari Senin pertama di bulan November, tidak ada suara dentang weker yang memecah keheningan kamar. Jam kuningan itu telah diamatikan sejak kemarin sore. Ketika mata Pak Darmo terbuka secara alami saat tirai jendela mulai diterpa warna keemasan fajar, dadanya sempat dihinggapi kepanikan singkat. Ia hampir melompat dari tempat tidur sebelum teringat satu kenyataan baru: ia telah resmi pensiun.</p>

      <p>Pak Darmo menarik napas dalam-dalam. Keheningan rumah terasa asing, namun perlahan menghangat. Istrinya, Bu Rahmi, sedang meletakkan cangkir keramik putih bergambar bunga melati di meja teras depan. Uap tipis mengepul manis membawa aroma biji kopi tubruk yang diseduh dengan air mendidih.</p>

      <p>"Pagi, Pak," sapa Bu Rahmi lembut seraya mengusap bahu suaminya. "Hari ini ndak usah keburu-buru."</p>

      <p>Pak Darmo melangkah keluar menuju teras kecil. Udara pagi terasa begitu jernih. Untuk pertama kalinya dalam tiga dekade, ia tidak perlu meminum kopinya dalam dua tegukan cepat yang membakar lidah demi mengejar bel pabrik. Ia duduk perlahan di kursi kayu jati tua, meraih cangkir hangat itu dengan kedua tangannya.</p>

      <p>Dari kursi teras, ia menyaksikan pemandangan yang selama puluhan tahun terlewatkan dari jarak pandang matanya. Ia melihat bagaimana sinar matahari pagi secara perlahan menyinari daun-daun pohon mangga di pekarangan, mengubah tetesan embun menjadi bulir-bulir kristal yang berkilauan. Ia melihat tetangganya membimbing anak balitanya belajar berjalan di atas rumput basah. Ia mendengar kicau burung pemakan ulat yang bersahut-sahutan riang di atas atap.</p>

      <p>Kopi tubruk itu diminumnya pelan-pelan. Rasa pahit yang pekat berpadu dengan gurih manisnya gula kelapa di ujung lidah. Pada tegukan ketiga, Pak Darmo tersenyum kecil. Ada rasa haru yang tiba-tiba menggenang di sudut matanya.</p>

      <p>Ia mengingat betapa banyak hal indah yang telah ia korbankan demi mempertahankan pacuan waktu. Masa kecil anak-anaknya yang berlalu begitu cepat tanpa sempat ia amati hari demi hari, ulang tahun pernikahan yang dirayakan seadanya di sela lembur malam, serta impian-impian kecil untuk melukis lanskap desa yang selalu ditundanya karena alasan tidak ada waktu.</p>

      <p>"Kopinya enak, Bu," bisik Pak Darmo seraya menatap istrinya yang sedang menyapu pekarangan depan.</p>

      <p>"Setiap pagi kopinya ya enak begitu, Pak. Cuma Sampeyan baru punya waktu buat ngerasain bener-bener hari ini," balas Bu Rahmi dengan senyuman hangat yang meliukkan kerutan halus di sudut matanya.</p>

      <p>Hari itu, Pak Darmo menyadari sebuah kebenaran sederhana tentang makna keberadaan manusia. Kehidupan bukanlah sebuah balapan lari maraton yang diukur dari seberapa cepat seseorang mencapai garis akhir atau seberapa banyak harta yang terkumpul di dalam gudang. Kehidupan adalah tentang keberanian untuk memperlambat langkah, membuka dada lapang-lapang, dan menikmati kehangatan secangkir kopi di pagi hari bersama orang-orang yang dicintai.</p>
    `
  },
  {
    id: 3,
    title: "Rintik Hujan di Halte 14",
    genre: "Kisah Remaja",
    readTime: "8 min",
    snippet: "Di bawah guyuran hujan lebat sore hari dan kebisingan jalanan kota, sepasang earphone kabel menjadi jembatan antara dua hati yang sama-sama pendiam...",
    content: `
      <h1>Rintik Hujan di Halte 14</h1>
      <div class="reader-meta-bar">
        <span>Penulis: <strong>Rasya Senandika</strong></span> • 
        <span>Genre: <strong>Kisah Remaja</strong></span> • 
        <span>Estimasi: <strong>1.500 Kata</strong></span>
      </div>

      <p>Langit di atas SMA Garuda mendadak berganti warna menjadi abu-abu pekat menjelang pukul empat sore. Tak lama kemudian, awan tebal itu pecah meluapkan ribuan liter air yang menghantam jalanan aspal dengan dentum deras. Murid-murid yang berhamburan keluar dari gerbang sekolah terpaksa berlarian mencari perlindungan di bawah atap seng Halte 14 yang sudah mengelupas catnya.</p>

      <p>Di sudut paling ujung halte itu, Maya berdiri menyandar pada tiang besi yang dingin. Tas punggungnya yang agak basah dipeluk erat di depan dada. Di sekelilingnya, riuh suara tawa dan obrolan teman-teman sekolah memecah kebisingan hujan. Namun Maya memilih diam, memperhatikan genangan air di tepi trotoar yang sesekali memantulkan bayangan lampu kendaraan yang melintas.</p>

      <p>Maya selalu merasa dirinya transparan. Di kelas, ia bukanlah murid terpandai yang kerap memenangkan trofi, bukan pula murid populer yang selalu menjadi pusat perhatian di kantin. Ia hanyalah gadis berseragam putih-abu-abu yang senang menggambar sketsa daun gugur di sudut buku catatannya.</p>

      <p>Tiba-tiba, aroma kayu cendana lembut dan bau pakaian bersih menguar di sebelah kirinya. Seorang remaja laki-laki berdiri di sana, mengibaskan sisa rintik air dari jaket denimnya. Itu Rasya—teman sekelasnya yang duduk di bangku paling belakang dekat jendela. Sama seperti Maya, Rasya dikenal sebagai sosok penikmat hening yang jarang bersuara kecuali jika dipanggil oleh guru.</p>

      <p>Rasya merogoh saku jaketnya, mengeluarkan seutas kabel earphone putih yang agak kusut. Ia memasang salah satu earbud ke telinga kirinya sendiri. Maya melirik canggung dari sudut matanya, berniat menggeser posisinya agar memberikan ruang lebih lega untuk Rasya.</p>

      <p>Namun sebelum Maya sempat melangkah, Rasya menoleh. Tanpa sepatah kata pun, ia mengulurkan earbud kanan yang satunya tepat di depan wajah Maya. Ibu jarinya memegang lembut kabel plastik putih itu.</p>

      <p>"Lagu ini... bagus kalau didengarkan pas hujan deres kayak gini," kata Rasya pelan. Suaranya hampir tenggelam oleh gemuruh gemercik air yang jatuh di atas atap halte.</p>

      <p>Maya terpaku sejenak. Jantungnya berdesir aneh seperti ketukan drum akustik. Dengan tangan yang agak gemetar, ia menerima earbud itu dan menyelipkannya ke telinga kanannya.</p>

      <p>Seketika itu juga, alunan petikan gitar akustik yang hangat meluncur lembut menyelimuti pendengarannya. Nada-nadanya tenang, mengalir bagaikan puisi malam yang melenyapkan segala kebisingan klakson mobil dan deru mesin bus kota. Hujan yang tadinya terasa dingin dan menjengkelkan mendadak menjelma menjadi latar latar visual yang indah.</p>

      <p>Selama dua puluh menit berikutnya, tak ada obrolan panjang di antara mereka berdua. Mereka hanya berdiri berdampingan di bawah lindungan seng Halte 14, mendengarkan daftar lagu indie folk yang diputar dari ponsel Rasya. Sesekali, jari jemari mereka tak sengaja bersentuhan ketika angin kencang berembus membawa cipratan air hujan.</p>

      <p>Saat bus nomor 07 yang ditunggu Rasya akhirnya merapat di tepi halte, Rasya melepas earbud kirinya dengan pelan. Ia menoleh ke arah Maya, melemparkan senyuman tipis yang membuat matanya membentuk kurva hangat.</p>

      <p>"Makasih udah mau dengerin lagu favoritku, Maya. Sampai ketemu besok di kelas ya," ucapnya hangat sebelum melangkah naik menaiki tangga bus.</p>

      <p>Maya berdiri terpaku menatap bus yang perlahan menjauh menembus tirai hujan. Tangan kanannya masih menyentuh telinganya sendiri yang terasa hangat. Untuk pertama kalinya dalam sejarah tiga tahun di SMA, Maya merasa bahwa berdiri di bawah hujan lebat sore hari bukanlah hal yang buruk sama sekali.</p>
    `
  },
  {
    id: 4,
    title: "Surat yang Tak Pernah Terkirim",
    genre: "Kehilangan",
    readTime: "9 min",
    snippet: "Mengemas barang-barang mendiang Ibu di rumah lama membuka rahasia tentang sepuluh tahun tumpukan surat berpita biru yang tak pernah sampai ke alamat perantauan...",
    content: `
      <h1>Surat yang Tak Pernah Terkirim</h1>
      <div class="reader-meta-bar">
        <span>Penulis: <strong>Rasya Senandika</strong></span> • 
        <span>Genre: <strong>Kehilangan</strong></span> • 
        <span>Estimasi: <strong>1.500 Kata</strong></span>
      </div>

      <p>Rumah beratap genteng jati tua di sudut kota kecamatan itu terasa begitu lapang sekaligus hampa. Sudah empat puluh hari sejak kepergian Ibu, namun aromanya—perpaduan antara bedak dingin, minyak kayu putih, dan wangi bunga melati kering—masih tertinggal kuat di setiap lipatan kain gorden dan sudut-sudut lemari kayu jati di kamar utamanya.</p>

      <p>Rasya memegang selotip cokelat dan beberapa kardus kosong di lantai. Sebagai anak tunggal yang telah sepuluh tahun hidup merantau di ibu kota demi mengejar karier dan impian besarnya, tugas merapikan barang-barang peninggalan orang tua terasa bagaikan menyusuri lorong kenangan yang penuh ranjau emosional.</p>

      <p>Setiap benda memiliki sejarah. Kacamata baca berkaki retak yang tersimpan di atas meja nakas, sejadah tenun yang agak menipis di bagian sujudnya, hingga cangkir teh enamel hijau yang tak pernah diganti. Namun saat Rasya memanjat tangga kayu melangkah menuju loteng atas untuk membersihkan peti-peti tua, ia menemukan sebuah kotak kayu mahoni berkunci gembok kuno.</p>

      <p>Menggunakan kunci kecil yang ditemukannya di bawah alas lemari Ibu, Rasya membuka tutup peti kayu tersebut. Di dalamnya, tidak ada perhiasan emas atau surat tanah yang berharga. Yang ada hanyalah sebundel tumpukan kertas amplop cokelat bertali pita biru yang telah pudar warnanya.</p>
      
      <p>Di atas setiap amplop, tertera nama dan alamat kontrakan lama Rasya di kota perantauan, ditulis rapi menggunakan tinta pulpen hitam dengan garis karakter tulisan tangan Ibu yang sangat khas. Namun, tidak ada satu pun perangko yang tertempel di sudut kanan atasnya.</p>

      <p>Dengan jemari yang sedikit bergetar, Rasya melepaskan ikatan pita biru tersebut dan membuka surat tertua berpenanggalan delapan tahun lalu.</p>

      <p><em>"Untuk Rasya, anakku tersayang di kota..."</em> buka surat pertama itu.</p>

      <p><em>"Pohon mangga arumanis di pekarangan depan rumah kita hari ini berbuah lebat sekali, Nak. Ibu memetik lima buah yang paling matang dan membayangkan betapa kamu akan senang memakannya seperti saat kamu masih sekolah dulu. Ibu tahu kamu sedang sibuk sekali dengan ujian dan pekerjaan barumu. Jangan lupa makan tepat waktu ya, Nak. Doa Ibu selalu menyertai setiap langkahmu dari rumah tua ini."</em></p>

      <p>Rasya membuka surat kedua berpenanggalan empat tahun berikutnya, saat kariernya di kota sedang berada di puncak kejayaan namun ia jarang sekali pulang bahkan saat hari raya.</p>

      <p><em>"Rasya, malam takbiran ini hujan turun deras sekali. Ibu memasak rendang kesukaanmu dan menaruh dua piring di meja makan. Kadang Ibu merasa rumah ini terlalu luas untuk Ibu tinggali sendiri. Tapi Ibu bangga sekali melihat foto yang kamu kirimkan minggu lalu. Anak laki-laki Ibu sudah jadi orang sukses di kota. Jangan khawatirkan Ibu di sini, Ibu selalu sehat dan bahagia..."</em></p>

      <p>Air mata Rasya tak sanggup ditahan lagi. Bulir-bulirnya menetes basah membasahi kertas lusuh berumur bertahun-tahun tersebut. Di dalam surat-surat itu, Ibu menceritakan segala hal kecil yang tak pernah sempat ia sampaikan di telepon demi tidak ingin mengganggu konsentrasi atau membebani pikiran anaknya yang sibuk.</p>

      <p>Ibu menceritakan bagaimana ia kerap berdiri di depan gerbang pekarangan setiap sore hari, berharap mendengar deru suara taksi yang membawa Rasya pulang. Ibu menceritakan bagaimana ia memajang setiap guntingan koran yang memuat berita atau prestasi kecil perusahaan Rasya.</p>

      <p>Mengapa surat-surat indah ini tak pernah dikirimkan? Di lembaran surat terakhir yang ditulis beberapa bulan sebelum Ibu masuk rumah sakit, ada jawabannya:</p>

      <p><em>"Ibu sengaja menyimpan surat-surat ini di dalam kotak, Nak. Ibu takut kalau Ibu mengirimkannya, surat ini justru akan membuat langkah kakimu terasa berat untuk terbang tinggi mengejar impianmu. Cukuplah surat ini jadi saksi bisu betapa Ibu selalu mencintaimu dari jauh."</em></p>

      <p>Di dalam loteng yang sunyi itu, Rasya memeluk bundelan surat berpita biru itu rapat-rapat ke dadanya. Penyesalan terhebat dalam hidup bukanlah tentang kegagalan mencapai impian, melainkan tentang waktu bersama orang tercinta yang terlewati begitu saja dan tak akan pernah bisa diputar kembali.</p>
    `
  },
  {
    id: 5,
    title: "Teka-Teki Ruang 404",
    genre: "Misteri",
    readTime: "10 min",
    snippet: "Cetak biru gedung perpustakaan tua 1920 menunjukkan ada sepuluh ruangan di lantai empat. Namun di koridor nyata, pintu nomor 404 lenyap dibalik beton berukir...",
    content: `
      <h1>Teka-Teki Ruang 404</h1>
      <div class="reader-meta-bar">
        <span>Penulis: <strong>Rasya Senandika</strong></span> • 
        <span>Genre: <strong>Misteri</strong></span> • 
        <span>Estimasi: <strong>1.500 Kata</strong></span>
      </div>

      <p>Sebagai seorang arsitek muda yang dipercaya memimpin proyek pemugaran Gedung Perpustakaan Kota berpola arsitektur Art Deco peninggalan tahun 1920-an, Dion selalu mengandalkan akurasi cetak biru kuno. Setiap pilar, cetakan semen, dan saluran udara diukur dengan presisi tinggi demi menjaga keaslian cagar budaya tersebut.</p>

      <p>Namun pada minggu ketiga restorasi, Dion menemukan sebuah kejanggalan matematis yang mengusik naluri arsitekturnya. Menurut cetak biru asli yang dilukis di atas kertas kalkir kusam bertanggal 14 Agustus 1924, lantai empat gedung tersebut dirancang memiliki sepuluh ruangan simetris dengan koridor utama di tengah-tengahnya.</p>

      <p>Tetapi saat Dion melakukan pengukuran lapangan langsung dari ujung lorong timur ke barat, hanya ada sembilan pintu kayu jati yang terpasang. Di antara Ruang 403 dan Ruang 405, tidak ada pintu sama sekali. Yang ada hanyalah sebuah dinding beton tebal yang dilapisi ornamen relief bundar tanpa fungsi struktural yang jelas.</p>

      <p>Dion mengambil meteran laser dan pita ukur kain. Berdasarkan perhitungan dimensi panjang koridor luar dan ketebalan dinding antar-ruangan, ada selisih ruang kosong berukuran kira-kira 6 x 8 meter yang tersembunyi di balik dinding beton padat tersebut. Sebuah ruangan misterius yang dengan sengaja dihilangkan dari kenyataan visual lorong.</p>

      <p>"Pak Dion, kata penjaga malam tua di gedung ini, dinding itu sengaja ditutup semen sejak zaman pendudukan Jepang," bisik Hendra, asisten lapangan muda yang mendampinginya.</p>

      <p>"Kenapa ditutup?" tanya Dion penasaran seraya mengetuk permukaan dinding semen itu dengan palu uji. Suaranya terdengar bergema tidak padat—menandakan ada rongga hampa besar di baliknya.</p>

      <p>"Tidak ada yang tahu pastinya, Pak. Tapi berkas dokumen arsip pegawai tahun 1950-an mencatat bahwa setiap kali ada pekerja yang mencoba melubangi dinding itu, seluruh sistem listrik di gedung ini akan mati mendadak dan alarm darurat berbunyi sendiri."</p>

      <p>Rasa penasaran teknis Dion mengalahkan takhayul lokal. Malam itu pukul delapan malam, setelah seluruh pekerja konstruksi pulang ke rumah masing-masing, Dion dan Hendra memutuskan untuk melakukan pemindaian termal serta ultrasonik ke permukaan dinding misterius tersebut.</p>

      <p>Alat pemindai ultrasonik menampilkan kontur mengejutkan di layar monitor laptop: di balik lapisan semen setebal tiga puluh sentimeter itu, terdapat sebuah pintu kayu jati ganda berkunci besi yang masih utuh. Dan yang lebih menggetarkan dada, pemindai termal menangkap adanya titik suhu hangat di dalam ruangan tertutup tanpa jendela itu—suhu yang menyerupai haba tubuh manusia yang sedang bergerak lambat.</p>

      <p>"Pak... ada sesuatu di dalam sana," desis Hendra dengan wajah pucat pasi.</p>

      <p>Dion mengambil pahat besi dan palu berat. Dengan dorongan adrenalin yang tinggi, ia menghantamkan pahat ke sudut ornamen semen yang paling rapuh. Pukulan demi pukulan meretakkan lapisan semen tua hingga berjatuhan ke lantai marmer.</p>

      <p>Debu putih mengepul tebal. Saat lubang selebar telapak tangan berhasil terbuka, bau udara yang sangat asing tersembur keluar—perpaduan antara aroma kertas koran kuno, minyak mesin mesin ketik tua, dan wangi lilin lebah yang segar, seolah-olah ruangan di dalam sana baru saja ditinggalkan penghuninya lima menit yang lalu.</p>

      <p>Dion mengarahkan lampu senter LED berdaya tinggi menembus celah lubang tersebut. Sinar terang itu menembus kegelapan Ruang 404.</p>

      <p>Di dalam ruangan yang tak tersentuh waktu selama seabad itu, terlihat meja kayu besar berderet mesin ketik manual dengan kertas yang masih terselip di rol ketiknya. Lemari-lemari arsip besi berdiri rapi memuat ribuan dokumen berlabel rahasia. Namun yang membuat jantung Dion berhenti berdetak sejenak adalah sebuah cermin besar di dinding seberang.</p>

      <p>Di dalam pantulan cermin itu, Dion tidak melihat bayangan dirinya yang sedang memegang senter di luar lubang. Cermin di dalam Ruang 404 itu justru memantulkan sosok seorang pria berpakaian jas era 1920-an yang sedang duduk di meja kerja, perlahan-lahan menghentikan ketikannya dan menolehkan wajahnya tepat ke arah lubang tempat mata Dion mengintip.</p>

      <p>Saat pria di dalam cermin itu tersenyum dan mengangkat pulpen tembaganya seolah menyapa, seluruh lampu di koridor lantai empat mendadak padam total. Suara ketikan mesin ketik manual berbunyi nyaring dari dalam ruangan tertutup tersebut...</p>
    `
  }
];

// ==========================================================================
// 2. DOM ELEMENTS & STATE MANAGEMENT
// ==========================================================================
let currentFontSizeRatio = 1.0; // 1.0 = 100% (1.08rem base)
const BASE_FONT_SIZE = 1.08;

const storyGrid = document.getElementById('storyGrid');
const searchInput = document.getElementById('searchInput');
const filterButtons = document.getElementById('filterButtons');
const themeToggle = document.getElementById('themeToggle');

// Reader Modal Elements
const readerModal = document.getElementById('readerModal');
const readerOverlay = document.getElementById('readerOverlay');
const readerArticle = document.getElementById('readerArticle');
const readerScrollArea = document.getElementById('readerScrollArea');
const closeReader = document.getElementById('closeReader');
const progressBar = document.getElementById('progressBar');
const modalGenre = document.getElementById('modalGenre');
const modalTime = document.getElementById('modalTime');
const fontUp = document.getElementById('fontUp');
const fontDown = document.getElementById('fontDown');
const fontSizeLabel = document.getElementById('fontSizeLabel');
const scrollTopBtn = document.getElementById('scrollTopBtn');

// ==========================================================================
// 3. RENDER CARDS & FILTER LOGIC
// ==========================================================================

function renderStories(data) {
  storyGrid.innerHTML = '';
  
  if (data.length === 0) {
    storyGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1rem; color: var(--text-muted);">
        <p style="font-size: 1.2rem; font-weight: 600;">Cerita tidak ditemukan 🔍</p>
        <p style="font-size: 0.95rem; margin-top: 0.5rem;">Coba gunakan kata kunci lain atau pilih kategori genre yang tersedia.</p>
      </div>
    `;
    return;
  }
  data.forEach(story => {
    const card = document.createElement('article');
    card.className = 'story-card';
    card.setAttribute('tabindex', '0');
    card.innerHTML = `
      <div class="card-header">
        <span class="card-genre-tag">${story.genre}</span>
        <h2 class="card-title">${story.title}</h2>
        <p class="card-snippet">${story.snippet}</p>
      </div>
      <div class="card-footer">
        <span>⏱️ ${story.readTime}</span>
        <span class="read-link">Baca Selengkapnya ➔</span>
      </div>
    `;
    
    // Open reader on click or Enter key
    card.addEventListener('click', () => openReader(story));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') openReader(story);
    });

    storyGrid.appendChild(card);
  });
}

function filterStories() {
  const searchTerm = searchInput.value.toLowerCase().trim();
  const activeGenre = document.querySelector('.filter-btn.active').dataset.genre;

  const filtered = stories.filter(story => {
    const matchesSearch = story.title.toLowerCase().includes(searchTerm) || 
                          story.snippet.toLowerCase().includes(searchTerm) ||
                          story.genre.toLowerCase().includes(searchTerm);
    const matchesGenre = activeGenre === 'all' || story.genre === activeGenre;
    return matchesSearch && matchesGenre;
  });

  renderStories(filtered);
}

// ==========================================================================
// 4. READER MODAL & READING LOGIC
// ==========================================================================

function openReader(story) {
  readerArticle.innerHTML = story.content;
  modalGenre.textContent = story.genre;
  modalTime.textContent = `⏱️ ${story.readTime}`;
  
  // Reset scroll & progress
  readerScrollArea.scrollTop = 0;
  progressBar.style.width = '0%';
  
  // Apply Font Size
  updateFontSize();

  // Show Modal
  readerModal.classList.add('active');
  readerModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

function closeReaderModal() {
  readerModal.classList.remove('active');
  readerModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = ''; // Restore scrolling
}

function updateFontSize() {
  const paragraphs = readerArticle.querySelectorAll('p');
  paragraphs.forEach(p => {
    p.style.fontSize = `${BASE_FONT_SIZE * currentFontSizeRatio}rem`;
  });
  fontSizeLabel.textContent = `${Math.round(currentFontSizeRatio * 100)}%`;
}

function adjustFont(delta) {
  const newRatio = currentFontSizeRatio + delta;
  if (newRatio >= 0.8 && newRatio <= 1.5) {
    currentFontSizeRatio = Number(newRatio.toFixed(1));
    updateFontSize();
  }
}

// Update progress bar on scroll
readerScrollArea.addEventListener('scroll', () => {
  const totalScroll = readerScrollArea.scrollHeight - readerScrollArea.clientHeight;
  if (totalScroll > 0) {
    const currentScroll = readerScrollArea.scrollTop;
    const progress = (currentScroll / totalScroll) * 100;
    progressBar.style.width = `${progress}%`;
  }
});
// Scroll to top inside modal
scrollTopBtn.addEventListener('click', () => {
  readerScrollArea.scrollTo({ top: 0, behavior: 'smooth' });
});

// Modal Event Listeners
closeReader.addEventListener('click', closeReaderModal);
readerOverlay.addEventListener('click', closeReaderModal);

fontUp.addEventListener('click', () => adjustFont(0.1));
fontDown.addEventListener('click', () => adjustFont(-0.1));

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && readerModal.classList.contains('active')) {
    closeReaderModal();
  }
});

// ==========================================================================
// 5. SEARCH, FILTER & THEME INITIALIZATION
// ==========================================================================

searchInput.addEventListener('input', filterStories);

filterButtons.addEventListener('click', (e) => {
  if (e.target.classList.contains('filter-btn')) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    e.target.classList.add('active');
    filterStories();
  }
});

// Theme Switcher (Dark Mode / Light Mode with LocalStorage)
function initTheme() {
  const savedTheme = localStorage.getItem('rasya_story_theme');
  if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.body.setAttribute('data-theme', 'dark');
    themeToggle.querySelector('.theme-icon').textContent = '☀️';
    themeToggle.querySelector('.theme-label').textContent = 'Light Mode';
  } else {
    document.body.removeAttribute('data-theme');
    themeToggle.querySelector('.theme-icon').textContent = '🌙';
    themeToggle.querySelector('.theme-label').textContent = 'Dark Mode';
  }
}

themeToggle.addEventListener('click', () => {
  const isDark = document.body.getAttribute('data-theme') === 'dark';
  if (isDark) {
    document.body.removeAttribute('data-theme');
    localStorage.setItem('rasya_story_theme', 'light');
    themeToggle.querySelector('.theme-icon').textContent = '🌙';
    themeToggle.querySelector('.theme-label').textContent = 'Dark Mode';
  } else {
    document.body.setAttribute('data-theme', 'dark');
    localStorage.setItem('rasya_story_theme', 'dark');
    themeToggle.querySelector('.theme-icon').textContent = '☀️';
    themeToggle.querySelector('.theme-label').textContent = 'Light Mode';
  }
});

// Run Initial Setup
initTheme();
renderStories(stories);